#ifndef _api_H_
#define _api_H_

#include  "../header/halGPIO.h"

extern void count_on_LCD();
void start_buzzing();
extern void x_to_int();
extern void disp_pot_val();
extern void my_negev();
extern void zero_all();

#endif
